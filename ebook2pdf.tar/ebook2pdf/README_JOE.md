### 해당 프로그램을 Mac, conda+pycharm에서 실행하기

import os
import sys
import time
import mss          # by pip3
import mss.tools
import pyautogui    # by pip3
import natsort      # by pip3
import shutil
